import React, { useState, useEffect, useMemo } from 'react';
import {
  CloudRain,
  Compass,
  Calendar,
  Gauge,
  Cpu,
  BookOpen,
  Layers,
  History,
  HelpCircle,
  Download,
  Briefcase,
  Sparkles,
  Volume2,
  VolumeX,
  ArrowUpRight,
  Bot,
  MessageSquare,
  Moon,
  Printer,
  FileText,
  Upload,
  Gamepad2,
  Globe,
  Trophy,
  Award,
  Flame,
  Search,
  X,
  Mountain,
  BrainCircuit,
  Activity,
} from 'lucide-react';
import { MET_STATIONS } from '../data/monsoonDataset';
import { DashboardEngineControls } from './DashboardEngineControls';
import { loadUserEngagement, UserEngagementState } from '../utils/achievements';
import { useExploreTour } from './exploreTour/ExploreTourContext';
import { ExploreBeacon } from './exploreTour/ExploreBeacon';

export type NavigationTab =
  | 'dashboard'
  | 'regimes'
  | 'probabilities'
  | 'districts'
  | 'verification'
  | 'diagnostics'
  | 'uploader'
  | 'predictor'
  | 'planner'
  | 'sandbox'
  | 'challenge'
  | 'achievements'
  | 'methodology'
  | 'help'
  | 'impact';

interface HeaderProps {
  selectedStationId: string;
  onStationChange: (id: string) => void;
  selectedLeadTime: number; // 0 = all, 1, 2, 3
  onLeadTimeChange: (lead: number) => void;
  selectedYear: number; // 0 = all, 2024, 2023
  onYearChange: (year: number) => void;
  selectedModelVersion: string;
  onModelVersionChange: (version: string) => void;
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  totalSamples: number;
  onDownloadReport?: () => void;
  onOpenBulletin?: () => void;
  onReplayIntro?: () => void;
  isAudioMuted?: boolean;
  onToggleAudio?: () => void;
  onOpenAchievements?: () => void;
  onOpenLocal3dSimulator?: (stationId: string) => void;
  onOpenTrainingGuide?: (tab?: 'explore' | 'ml_guide' | 'ml_trainer' | 'ui_spec') => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedStationId,
  onStationChange,
  selectedLeadTime,
  onLeadTimeChange,
  selectedYear,
  onYearChange,
  selectedModelVersion,
  onModelVersionChange,
  activeTab,
  onTabChange,
  totalSamples,
  onDownloadReport,
  onOpenBulletin,
  onReplayIntro,
  isAudioMuted,
  onToggleAudio,
  onOpenAchievements,
  onOpenLocal3dSimulator,
  onOpenTrainingGuide,
}) => {
  const [isNightMode, setIsNightMode] = useState(() => document.body.classList.contains('dark-black-font-mode'));
  const [stationSearchQuery, setStationSearchQuery] = useState<string>('');
  const { openTourModal, seenIds, totalCount } = useExploreTour();

  const filteredHeaderStations = useMemo(() => {
    const q = stationSearchQuery.trim().toLowerCase();
    const digitsOnly = q.replace(/[^0-9]/g, '');
    const parsedIndex = digitsOnly ? parseInt(digitsOnly, 10) : null;

    return MET_STATIONS.map((stn, idx) => ({
      ...stn,
      idx,
      regionIndex: idx + 1,
      paddedIndex: String(idx + 1).padStart(2, '0'),
    })).filter((stn) => {
      if (!q) return true;
      if (parsedIndex !== null && stn.regionIndex === parsedIndex) return true;
      const idxStr = String(stn.regionIndex);
      if (
        q === idxStr || 
        q === stn.paddedIndex || 
        q === `#${idxStr}` || 
        q === `#${stn.paddedIndex}` ||
        `#${stn.regionIndex}`.includes(q)
      ) {
        return true;
      }
      if (stn.name.toLowerCase().includes(q)) return true;
      if (stn.subdivision.toLowerCase().includes(q)) return true;
      if (stn.state.toLowerCase().includes(q)) return true;
      if (stn.id.toLowerCase().includes(q)) return true;
      if (stn.climateZone.toLowerCase().includes(q)) return true;
      return false;
    });
  }, [stationSearchQuery]);

  return (
    <header id="app-header" className="bg-slate-900 border-b border-slate-800 text-white relative">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-400 mt-1 hidden sm:block">
              <CloudRain className="w-7 h-7" />
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 text-xs font-bold tracking-wide rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  SAMVARTAKA AI
                </span>
                <span className="px-2 py-0.5 text-xs font-medium rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Verified ML Pipeline Active
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  {selectedYear === 0
                    ? "Multi-Season Benchmark (2023 - 2025)"
                    : selectedYear === 2025
                    ? "2025 Operational Season (June - Sept)"
                    : selectedYear === 2024
                    ? "2024 Season (June - Sept)"
                    : "2023 Historical Benchmark (June - Sept)"}
                </span>

                {onReplayIntro && (
                  <button
                    id="replay-intro-showcase-btn"
                    onClick={onReplayIntro}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-purple-900/80 via-fuchsia-900/70 to-indigo-900/80 hover:from-purple-800 hover:to-indigo-800 border border-purple-400/50 text-purple-200 text-xs font-bold shadow-[0_0_20px_rgba(168,85,247,0.35)] transition-all hover:scale-105 active:scale-95 cursor-pointer ml-auto sm:ml-2"
                    title="Watch SAMVARTAKA AI Cinematic Intro (Twin Peaks & Cascading Waterfall)"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-purple-300 animate-spin" />
                    <span>Intro Showcase</span>
                    <ArrowUpRight className="w-3 h-3 text-purple-300" />
                  </button>
                )}
              </div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1 flex flex-wrap items-center gap-2">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-300 font-black tracking-tight">
                  SAMVARTAKA AI
                </span>
                <span className="text-slate-500 font-normal hidden sm:inline">|</span>
                <span>Regime-Aware Rainfall Post-Processor</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                Physics-informed machine learning post-processor eliminating NWP drizzle bias and resolving smoothed convective extremes
              </p>
            </div>
          </div>

          {/* Quick Header Status & Actions on the Right */}
          <div className="flex items-center gap-2 self-start md:self-auto shrink-0">
            {onOpenBulletin && (
              <button
                id="header-bulletin-quick-btn"
                onClick={onOpenBulletin}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-950/60 hover:bg-blue-900/70 border border-blue-800/60 text-blue-200 hover:text-white text-xs font-semibold transition-all cursor-pointer shadow-xs"
                title="View Operational Weather Advisory Bulletin"
              >
                <FileText className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Advisory Bulletin</span>
              </button>
            )}
            {onDownloadReport && (
              <button
                id="header-dossier-quick-btn"
                onClick={onDownloadReport}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 hover:text-white text-xs font-semibold transition-all cursor-pointer"
                title="Download IMD Meteorological Evaluation Dossier"
              >
                <Download className="w-3.5 h-3.5 text-indigo-300" />
                <span className="hidden sm:inline">Export Dossier</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-3">
            {/* Monsoon Season Year Filter (Recent vs Multi-Year) */}
            <div className="flex items-center gap-2">
              <History className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-slate-400 font-medium">Monsoon Season:</span>
              <div className="inline-flex rounded-md shadow-xs bg-slate-800 p-0.5 border border-slate-700">
                <button
                  id="year-2025-btn"
                  onClick={() => onYearChange(2025)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-colors flex items-center gap-1 ${
                    selectedYear === 2025
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  2025 Season
                </button>
                <button
                  id="year-2024-btn"
                  onClick={() => onYearChange(2024)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                    selectedYear === 2024
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  2024 Season
                </button>
                <button
                  id="year-2023-btn"
                  onClick={() => onYearChange(2023)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                    selectedYear === 2023
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  2023 Season
                </button>
                <button
                  id="year-all-btn"
                  onClick={() => onYearChange(0)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                    selectedYear === 0
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Combined (2023-2025)
                </button>
              </div>
            </div>

            {/* Station Filter with Quick Search */}
            <div className="flex items-center gap-2">
              <Compass className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span className="text-slate-400 font-medium whitespace-nowrap">Met Station:</span>

              {/* Station Search Input */}
              <div className="relative flex items-center">
                <Search className="w-3 h-3 text-slate-400 absolute left-2 pointer-events-none" />
                <input
                  id="header-station-search-input"
                  type="text"
                  value={stationSearchQuery}
                  onChange={(e) => setStationSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && filteredHeaderStations.length > 0) {
                      onStationChange(filteredHeaderStations[0].id);
                    }
                  }}
                  placeholder="Filter name or #idx..."
                  className="w-28 sm:w-36 bg-slate-800 border border-slate-700 rounded-md pl-6 pr-5 py-1 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 font-medium transition-all"
                  title="Quickly search meteorological stations by name or region index (e.g. 'Mumbai', '#04', 'Konkan')"
                />
                {stationSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setStationSearchQuery('')}
                    className="absolute right-1 text-slate-400 hover:text-white cursor-pointer"
                    title="Clear filter"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              <select
                id="station-filter-select"
                value={selectedStationId}
                onChange={(e) => onStationChange(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1 text-xs text-white focus:outline-none focus:border-blue-500 font-medium max-w-[170px] sm:max-w-[260px] truncate"
              >
                <option value="ALL">
                  All Stations {stationSearchQuery ? `(${filteredHeaderStations.length} of ${MET_STATIONS.length})` : `(${MET_STATIONS.length} Subdivisions)`}
                </option>
                {filteredHeaderStations.map((stn) => (
                  <option key={stn.id} value={stn.id}>
                    #{stn.paddedIndex} {stn.name} — {stn.subdivision}
                  </option>
                ))}
              </select>

              {onOpenLocal3dSimulator && (
                <button
                  type="button"
                  onClick={() => onOpenLocal3dSimulator(selectedStationId !== 'ALL' ? selectedStationId : 'BOM_SANTACRUZ')}
                  className="px-2 py-1 rounded bg-blue-600/30 hover:bg-blue-600 border border-blue-500/50 hover:border-blue-500 text-blue-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shrink-0"
                  title="Experience selected station in 3D ground simulator"
                >
                  <Mountain className="w-3 h-3 text-cyan-300" />
                  <span className="hidden xl:inline">3D Sim</span>
                </button>
              )}
            </div>

            {/* Lead Time Filter */}
            <div className="flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-slate-400 font-medium">Lead Time:</span>
              <div className="inline-flex rounded-md shadow-xs bg-slate-800 p-0.5 border border-slate-700">
                <button
                  id="lead-all-btn"
                  onClick={() => onLeadTimeChange(0)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                    selectedLeadTime === 0
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All Leads
                </button>
                <button
                  id="lead-d1-btn"
                  onClick={() => onLeadTimeChange(1)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                    selectedLeadTime === 1
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Day +1
                </button>
                <button
                  id="lead-d2-btn"
                  onClick={() => onLeadTimeChange(2)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                    selectedLeadTime === 2
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Day +2
                </button>
                <button
                  id="lead-d3-btn"
                  onClick={() => onLeadTimeChange(3)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                    selectedLeadTime === 3
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Day +3
                </button>
              </div>
            </div>

            {/* Model Version Dropdown */}
            <div className="flex items-center gap-2">
              <BrainCircuit className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-400 font-medium">Model:</span>
              <select
                value={selectedModelVersion}
                onChange={(e) => onModelVersionChange(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1 text-xs text-white focus:outline-none focus:border-emerald-500 font-medium max-w-[260px]"
              >
                <option value="v3.2">v3.2 (1901–2025 Climatology Ensemble - Active)</option>
                <option value="v3.1">v3.1 (Trained Quantile Model - 2023/24)</option>
                <option value="v3.0">v3.0 (Ensemble - Heuristic Baseline)</option>
                <option value="v2.0">v2.0 (Regime-Aware QRF)</option>
                <option value="v1.0">v1.0 (Linear Baseline)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2 text-slate-400">
            <Layers className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              Active Evaluation Sample: <strong className="text-white font-mono">{totalSamples}</strong> paired daily records
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
